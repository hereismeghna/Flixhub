# FlixHub

Made from Scratch with pure HTML CSS and PHP, Its a Dynamic Movie Browsing site, Where you can browse through the Movie titles.
Movies and loaded from the MySql Database using PHP.
A user can also create his/her account and Login to save thier favourite movies, which can be viewed from thir profile.
New movies can be added directly thorugh Database.

Its a work in Progress, I Hope to add more functionality to it soon..
